
# Marito Media Site

Sitio portfolio rápido para Marito Media.  
Tecnologías: React + Vite + Tailwind + Framer Motion.

## Scripts

```bash
npm install       # instala dependencias
npm run dev       # servidor local
npm run build     # build de producción
npm run preview   # prueba build
```

Subilo a GitHub, conectalo a Vercel y listo.
